# AngryBus  
##(Site para reclamacoes sobre o transporte publico de Sao Paulo);  
### O terminal solucao para seus problemas com o transporte publico;  
#### Criado e idealizado por Amanda, Jardel, Lucas e Vinicius.  


>Site **AngryBus - O terminal da soluçao - O terminal soluçao para seus problemas com o transporte publico da cidade de Sao Paulo**, Nao temos nenhuma ligaçao com empresas do ramo, somos a sua voz (reclamante) a eles, somente isso.  
Nosso logo e inspiracao para o nome ('AngryBus') sao uma reproduçao dos personagens e jogo da [Rovio Entertainment Ltd. ou Rovio](http://www.rovio.com), **sem fins lucrativos**, somente para uso academico e com todos os direitos reservados a ela.  

>>O intuito do nosso site e facilitar ambas as partes, tanto usuario do transporte, quanto empresa [A São Paulo Transporte LTDA ou SPTrans](http://www.sptrans.com.br), para solucionar e melhorar.
Atraves de mensagens de e-mail, levamos a reclamacao do passageiro e fazemos uma primeira intervencao, podemos ate (ideia não implementada) em algum momento liberar um modo de conversa ou chat ao vivo entre um atendente da SPTrans e reclamante.

>Trabalho feito para a NAC10-01-SEM1/2015 à materia de Desenvolvimento Web do professor Alexandre Carlos, do curso de TDS (Tecnologo em Analise e Desenvolvimento de Sistemas), Turma T noturno da FIAP (Faculdade de Informatica e Administracao Paulista).